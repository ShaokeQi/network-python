#shaokeQi 919455788
import socket
from datetime import datetime
import time

# so over there we set total packet size
PACKET_SIZE = 1024
# 
SEQ_ID_SIZE = 4
# 
MESSAGE_SIZE = PACKET_SIZE - SEQ_ID_SIZE

# ini win size
INITIAL_WINDOW_SIZE = 1

# slow the threshold
SLOW_START_THRESHOLD = 64

# read data
with open('file.mp3', 'rb') as f:
    data = f.read()

start_time = time.time()
send_packet_time = {}
recv_ack_time = {}
send_data_len = len(data)
 
# create udp
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as udp_socket:

    # bind socket
    udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    udp_socket.bind(("0.0.0.0", 5000))
    udp_socket.settimeout(1)
    
    # start with 0th
    seq_id = 0
    cur_cwnd = INITIAL_WINDOW_SIZE
    cur_threshold = SLOW_START_THRESHOLD
    duplicate_ack_count = 0
    last_ack_id = -1
    while seq_id < len(data):
        
        # create messages
        messages = []
        seq_id_tmp = seq_id

        for i in range(int(cur_cwnd)):
            
            message = int.to_bytes(seq_id_tmp, SEQ_ID_SIZE, byteorder='big', signed=True) + data[seq_id_tmp : min(seq_id_tmp + MESSAGE_SIZE, len(data))]
            
            
            seq_id_tmp = min(seq_id_tmp + MESSAGE_SIZE, len(data))
            messages.append((seq_id_tmp, message))
            if seq_id_tmp >= len(data):
                break
            

        # send messages
        for seq_id_t, message in messages:
            send_packet_time[seq_id_t] = time.time()
            udp_socket.sendto(message, ('localhost', 5001))
		
        last_ack_id = -1
        # wait for acknowledgement
        while len(messages) > 0:
            try:
                # wait for ack
                ack, _ = udp_socket.recvfrom(PACKET_SIZE)
                
                # extract ack id
                ack_id = int.from_bytes(ack[:SEQ_ID_SIZE], byteorder='big')
                # print(f'ack_id:{ack_id}')
                recv_ack_time[ack_id] = time.time()

                if ack_id == last_ack_id:
                    duplicate_ack_count += 1
                    if duplicate_ack_count == 3:
                        cur_threshold = max(cur_cwnd // 2, 1)
                        cur_cwnd = INITIAL_WINDOW_SIZE
                        duplicate_ack_count = 0
                        break
                else:
                    last_ack_id = ack_id
                    duplicate_ack_count = 0
                    messages = [message for message in messages if message[0] > ack_id]
                    # slow start
                    if cur_cwnd < cur_threshold:
                        cur_cwnd += 1
                    else:
                        cur_cwnd += 1 / cur_cwnd
                        
                
            except socket.timeout:
                cur_threshold = max(cur_cwnd // 2, 1)
                cur_cwnd = INITIAL_WINDOW_SIZE
                duplicate_ack_count = 0
                break
        # move sequence id forward
        seq_id = seq_id_tmp - MESSAGE_SIZE * len(messages)       
        # print(f'seq_id_tmp = {seq_id_tmp}, seq_id = {seq_id}, len(messages) = {len(messages)}')
        
    # send final closing message
    udp_socket.sendto(int.to_bytes(-1, 4, signed=True, byteorder='big') + b'==FINACK==', ('localhost', 5001))

end_time = time.time()
throughput = len(data) / (end_time - start_time)
delays = []
for ack_id in sorted(list(recv_ack_time.keys())):
    delays.append(recv_ack_time[ack_id] - send_packet_time[ack_id])
avg_delay = sum(delays) / len(delays)
jitters = [abs(delays[i] - delays[i-1]) for i in range(1, len(delays))]
avg_jitter = sum(jitters) / len(jitters)
print(f"Throughput: {throughput:.7f} bytes/sec")
print(f"Average Per-Packet Delay: {avg_delay:.7f} sec, Average Jitter: {avg_jitter:.7f} sec")
print(f"Metric: {(0.2 * throughput + 0.1 / avg_jitter + 0.8 / avg_delay):.7f}")
            

