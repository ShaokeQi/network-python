#Shaoke Qi 919455788
import socket
from datetime import datetime
import time

# here we set total packet size
PACKET_SIZE = 1024
# and the bytes reserved for sequence id
SEQ_ID_SIZE = 4
# here the bytes available for message
MESSAGE_SIZE = PACKET_SIZE - SEQ_ID_SIZE

# and here we got total packets to send
WINDOW_SIZE = 100

# first we gonna read data
with open('file.mp3', 'rb') as f:
    data = f.read()

start_time = time.time()
send_packet_time = {}
recv_ack_time = {}
send_data_len = len(data)
 
# then we need udp socket
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as udp_socket:

    # also over there that bind the socket to a OS port
    udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    udp_socket.bind(("0.0.0.0", 5000))
    udp_socket.settimeout(1)
    
    # we start sending data since 0th
    seq_id = 0
    
    while seq_id < len(data):
        
        # create the messages
        messages = []
        acks = {}
        seq_id_tmp = seq_id

        for i in range(WINDOW_SIZE):
            # for now we need construct messages
            message = int.to_bytes(seq_id_tmp, SEQ_ID_SIZE, byteorder='big', signed=True) + data[seq_id_tmp : min(seq_id_tmp + MESSAGE_SIZE, len(data))]
            
            
            seq_id_tmp = min(seq_id_tmp + MESSAGE_SIZE, len(data))
            messages.append((seq_id_tmp, message))
            acks[seq_id_tmp] = False
            if seq_id_tmp >= len(data):
                break
            

        # send messages
        for seq_id_t, message in messages:
            send_packet_time[seq_id_t] = time.time()
            udp_socket.sendto(message, ('localhost', 5001))

        # wait for aack
        while True:
            try:
                ack, _ = udp_socket.recvfrom(PACKET_SIZE)
                
                #
                ack_id = int.from_bytes(ack[:SEQ_ID_SIZE], byteorder='big')
                recv_ack_time[ack_id] = time.time()
                acks[ack_id] = True
                
                # 
                if ack_id == seq_id_tmp:
                    break
            except socket.timeout:
                # 
                for sid, message in messages:
                    if not acks[sid]:
                        #print(f'resend {sid}')
                        udp_socket.sendto(message, ('localhost', 5001))
                
        # 
        seq_id += MESSAGE_SIZE * WINDOW_SIZE
        
    # 
    udp_socket.sendto(int.to_bytes(-1, 4, signed=True, byteorder='big') + b'==FINACK==', ('localhost', 5001))

end_time = time.time()
throughput = len(data) / (end_time - start_time)
delays = []
for ack_id in sorted(list(recv_ack_time.keys())):
    delays.append(recv_ack_time[ack_id] - send_packet_time[ack_id])
avg_delay = sum(delays) / len(delays)
jitters = [abs(delays[i] - delays[i-1]) for i in range(1, len(delays))]
avg_jitter = sum(jitters) / len(jitters)
print(f"Throughput: {throughput:.7f} bytes/sec")
print(f"Average Per-Packet Delay: {avg_delay:.7f} sec, Average Jitter: {avg_jitter:.7f} sec")
print(f"Metric: {(0.2 * throughput + 0.1 / avg_jitter + 0.8 / avg_delay):.7f}")
            

