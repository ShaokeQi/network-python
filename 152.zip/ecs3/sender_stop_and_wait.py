#ShaokeQi 919455788
import socket
from datetime import datetime
import time


PACKET_SIZE = 1024

SEQ_ID_SIZE = 4

MESSAGE_SIZE = PACKET_SIZE - SEQ_ID_SIZE


WINDOW_SIZE = 1


with open('file.mp3', 'rb') as f:
    data = f.read()

start_time = time.time()
send_packet_time = {}
recv_ack_time = {}
send_data_len = len(data)
 

with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as udp_socket:

    # bind the socket to a OS port
    udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    udp_socket.bind(("0.0.0.0", 5000))
    udp_socket.settimeout(1)
    
    
    seq_id = 0
    while seq_id < len(data):
        
        # create messages
        messages = []
        acks = {}
        seq_id_tmp = seq_id
        for i in range(WINDOW_SIZE):
            message = int.to_bytes(seq_id_tmp, SEQ_ID_SIZE, byteorder='big', signed=True) + data[seq_id_tmp : min(seq_id_tmp + MESSAGE_SIZE, len(data))]
            
            seq_id_tmp = min(seq_id_tmp + MESSAGE_SIZE, len(data))
            messages.append((seq_id_tmp, message))
            acks[seq_id_tmp] = False
            

        
        for seq_id_t, message in messages:
            send_packet_time[seq_id_t] = time.time()
            udp_socket.sendto(message, ('localhost', 5001))
            
        
        while True:
            try:
               
                ack, _ = udp_socket.recvfrom(PACKET_SIZE)
                
                ack_id = int.from_bytes(ack[:SEQ_ID_SIZE], byteorder='big')
                acks[ack_id] = True
                #print(f'ack id: {ack_id}')
                recv_ack_time[ack_id] = time.time()

                # all acks received, move on
                if ack_id == seq_id_tmp:
                    break
            except socket.timeout:
                # no ack received, resend unacked messages
                for sid, message in messages:
                    if not acks[sid]:
                        udp_socket.sendto(message, ('localhost', 5001))
                
        seq_id += MESSAGE_SIZE * WINDOW_SIZE
        
    udp_socket.sendto(int.to_bytes(-1, 4, signed=True, byteorder='big') + b'==FINACK==', ('localhost', 5001))

end_time = time.time()
throughput = len(data) / (end_time - start_time)
delays = []
for ack_id in sorted(list(recv_ack_time.keys())):
    delays.append(recv_ack_time[ack_id] - send_packet_time[ack_id])
avg_delay = sum(delays) / len(delays)
jitters = [abs(delays[i] - delays[i-1]) for i in range(1, len(delays))]
avg_jitter = sum(jitters) / len(jitters)
print(f"Throughput: {throughput:.7f} bytes/sec")
print(f"Average Per-Packet Delay: {avg_delay:.7f} sec, Average Jitter: {avg_jitter:.7f} sec")
print(f"Metric: {(0.2 * throughput + 0.1 / avg_jitter + 0.8 / avg_delay):.7f}")
            

