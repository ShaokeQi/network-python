import socket
import datetime
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def get_time_str():
    """Get the current time as a formatted string."""
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')


def get_time_double(time_str):
    """Convert a formatted time string to a timestamp."""
    ts = datetime.datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S.%f')
    return ts.timestamp()


def start_server():
    ip_addr = ("127.0.0.1", 10086)  # Server IP and port
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_socket.bind(ip_addr)

    logging.info("------- Server is running -------")

    try:
        while True:
            data, recv_addr = udp_socket.recvfrom(1024)
            data = data.decode('utf-8')

            try:
                # Split the payload and timestamp using the delimiter
                payload, timestamp_str = data.rsplit('|', 1)
                recv_t = get_time_double(get_time_str())
                send_t = get_time_double(timestamp_str.strip())

                logging.info(f"Received data from {recv_addr}")
                logging.info(f"Timestamps - Received: {recv_t}, Sent: {send_t}")

                # Calculate time difference
                diff_t = recv_t - send_t
                if diff_t <= 0:
                    udp_socket.sendto(b"Error: Time difference is zero or negative", recv_addr)
                    continue

                # Calculate speed in kbps
                speed = (len(payload) / diff_t) / 1024
                response = f"{speed:.2f} kbps"
                udp_socket.sendto(response.encode('utf-8'), recv_addr)

            except ValueError as e:
                logging.error(f"Data parsing error: {e}")
                udp_socket.sendto(b"Error: Invalid data format", recv_addr)

    except socket.error as e:
        logging.error(f"Socket error: {e}")
    except KeyboardInterrupt:
        logging.info("Shutting down the server.")
    finally:
        udp_socket.close()


if __name__ == "__main__":
    start_server()