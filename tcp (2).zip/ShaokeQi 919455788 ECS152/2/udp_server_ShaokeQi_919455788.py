import socket
import datetime
import time


def getTimeStr():
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')


def getTimeDouble(timeStr):
    ts = datetime.datetime.strptime(timeStr, '%Y-%m-%d %H:%M:%S.%f')
    return ts.timestamp()


def main():
    ip_addr = ("127.0.0.1", 5500)  # udp ip address
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_socket.bind(ip_addr)
    print('--hey our server is running--')
    while True:
        data, recv_addr = udp_socket.recvfrom(1024)
        data = data.decode('ascii')
        recv_t = getTimeDouble(getTimeStr())
        send_t = getTimeDouble(data[81:])
        print(recv_t, send_t)
        diff_t = recv_t - send_t
        if diff_t == 0:
            udp_socket.sendto(bytes("run too fast, receive 100 bytes in one us", encoding='ascii'), recv_addr)
            continue
        speed = 100 / diff_t / 1024
        udp_socket.sendto(bytes(str(speed) + "/kbps", encoding='ascii'), recv_addr)
    return


if __name__ == '__main__':
    main()

    
    
