import socket
import datetime
import time

def getTimeStr():
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')

def getTimeInt(timeStr):
    ts = datetime.datetime.strptime(timeStr, '%Y-%m-%d %H:%M:%S.%f')
    return ts.timestamp()

def main():
    ip_addr = ("127.0.0.1", 5500) #udp ip address
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    data = ''
    for i in range(81):
        data += '1'
    data += getTimeStr()
    
    udp_socket.sendto(bytes(data, encoding = 'ascii'), ip_addr)
    speed_data, recv_addr = udp_socket.recvfrom(100)
    print(speed_data.decode('ascii'))
    return

if __name__ == '__main__':
    main()
    
    
    
