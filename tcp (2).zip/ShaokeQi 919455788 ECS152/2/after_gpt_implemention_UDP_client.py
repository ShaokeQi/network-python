import socket
import datetime
import time


def get_time_str():
    """Get the current time as a formatted string."""
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')


def get_time_int(time_str):
    """Convert a formatted time string to a timestamp."""
    ts = datetime.datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S.%f')
    return ts.timestamp()


def send_data():
    ip_addr = ("127.0.0.1", 10086)  # Server IP and port
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    try:
        for i in range(10):
            # Construct the data payload
            data = '1' * 81 + '|' + get_time_str()
            udp_socket.sendto(data.encode('utf-8'), ip_addr)

            # Receive response from the server
            speed_data, recv_addr = udp_socket.recvfrom(100)
            print("Server response:", speed_data.decode('utf-8'))
            time.sleep(1)
    except socket.error as e:
        print(f"Socket error: {e}")
    finally:
        udp_socket.close()


if __name__ == "__main__":
    send_data()
