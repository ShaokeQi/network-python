import dpkt
import socket
import sys

# Optimized dictionary for protocol identification
PORT_PROTOCOL_MAP = {
    80: "HTTP",
    443: "HTTPS",
    21: "FTP",
    25: "SMTP",
    110: "POP3",
    143: "IMAP",
    22: "SSH",
    53: "DNS",
    123: "NTP"
}

def identify_application_layer(sport, dport):
    """Identify the application layer protocol using a dictionary lookup."""
    return PORT_PROTOCOL_MAP.get(sport) or PORT_PROTOCOL_MAP.get(dport)

def has_secret_data(ip_data):
    """Check if the packet contains secret data."""
    src_port = ip_data.sport
    dest_port = ip_data.dport
    http_data = None

    try:
        if src_port == 80 or dest_port == 80:
            # Parse HTTP response or request based on the data content
            if ip_data.data.startswith(b'HTTP'):
                http_data = dpkt.http.Response(ip_data.data)
            else:
                http_data = dpkt.http.Request(ip_data.data)
    except (dpkt.dpkt.UnpackError, ValueError):
        return False

    # Check for 'secret' in headers efficiently
    return http_data and 'secret' in http_data.headers

def analyze_pcap(filename):
    """Analyze the given PCAP file and count protocol usage and secret data."""
    protocol_count = {protocol: 0 for protocol in PORT_PROTOCOL_MAP.values()}
    secret_count = 0

    with open(filename, 'rb') as f:
        pcap = dpkt.pcap.Reader(f)

        for timestamp, buf in pcap:
            try:
                eth = dpkt.ethernet.Ethernet(buf)
                if not isinstance(eth.data, dpkt.ip.IP):
                    continue

                ip = eth.data
                ip_data = ip.data

                # Check if it's a TCP or UDP packet
                if isinstance(ip_data, (dpkt.tcp.TCP, dpkt.udp.UDP)):
                    src_port = ip_data.sport
                    dest_port = ip_data.dport
                    protocol_name = identify_application_layer(src_port, dest_port)

                    if protocol_name:
                        protocol_count[protocol_name] += 1

                    # Check for secret data only in TCP packets
                    if isinstance(ip_data, dpkt.tcp.TCP) and has_secret_data(ip_data):
                        secret_count += 1

            except (dpkt.UnpackError, AttributeError) as e:
                print(f"Error processing packet: {e}")

    # Output the analysis results
    print(protocol_count)
    print(f"Total secret data occurrences: {secret_count}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python analyze_pcap.py <pcap_filename>")
        sys.exit(1)

    analyze_pcap(sys.argv[1])
