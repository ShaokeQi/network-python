import dpkt
import socket
import sys


def hasSecretData(ip_data):
    src_port = ip_data.sport
    dest_port = ip_data.dport
    http_data = None
    try:
        if src_port == 80 or dest_port == 80:
            if ip_data.data.startswith(b'HTTP'):
                http_data = dpkt.http.Response(ip_data.data)
            elif any(ip_data.data.startswith(method.encode()) for method in
                     ['GET', 'POST', 'HEAD', 'PUT', 'DELETE', 'OPTIONS']):
                http_data = dpkt.http.Request(ip_data.data)

    except (dpkt.dpkt.UnpackError, ValueError) as e:
        pass

    if http_data is None:
        return False

    if 'secret' in http_data.headers:
        print(f"secret data:{http_data.headers['secret']}")
        return True
    return False


def identify_application_layer(sport, dport):
    if dport == 80 or sport == 80:
        return "HTTP"
    elif dport == 443 or sport == 443:
        return "HTTPS"
    elif dport == 21 or sport == 21:
        return "FTP"
    elif dport == 25 or sport == 25:
        return "SMTP"
    elif dport == 110 or sport == 110:
        return "POP3"
    elif dport == 143 or sport == 143:
        return "IMAP"
    elif dport == 22 or sport == 22:
        return "SSH"
    elif dport == 53 or sport == 53:
        return "DNS"
    elif dport == 123 or sport == 123:
        return "NTP"
    return None
def main():
    filename = sys.argv[1]
    protocols = ["HTTP", "HTTPS", "FTP", "SMTP", "POP3", "IMAP", "SSH", "DNS", "NTP", "ICMP","IGMP"]
    protocol_count = {protocol: 0 for protocol in protocols}
    secret_count = 0
    with open(filename, 'rb') as f:
        pcap = dpkt.pcap.Reader(f)

        for timestamp, buf in pcap:
            try:
                eth = dpkt.ethernet.Ethernet(buf)
                ip = eth.data
                ip_data = ip.data
                if isinstance(ip_data, dpkt.icmp.ICMP):
                    protocol_count['ICMP'] += 1
                    continue
                if isinstance(eth.data, dpkt.ip.IP):
                    if isinstance(ip_data, dpkt.igmp.IGMP):
                        protocol_count['IGMP'] += 1
                        continue
                    src_ip = socket.inet_ntoa(ip.src)
                    dest_ip = socket.inet_ntoa(ip.dst)
                    src_port = ip_data.sport
                    dest_port = ip_data.dport
                    print(f'Timestamp: {timestamp}, src: ({src_ip}, {src_port}), dest: ({dest_ip},{dest_port})')
                if isinstance(ip.data, dpkt.tcp.TCP) or isinstance(ip.data, dpkt.udp.UDP):
                    src_port = ip_data.sport
                    dest_port = ip_data.dport
                    if identify_application_layer(src_port, dest_port) != None:
                        protocol_count[identify_application_layer(src_port, dest_port)] += 1

                if isinstance(ip.data, dpkt.tcp.TCP) and hasSecretData(ip_data):
                    secret_count += 1

            except dpkt.UnpackError as e:
                print(f'UnpackError:{e}')
        print(protocol_count)
        print(f'This pcap has {secret_count} secrets data')
    return


if __name__ == '__main__':
    main()
