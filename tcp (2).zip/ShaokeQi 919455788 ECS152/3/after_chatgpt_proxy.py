import socket
import json


def main():
    ip_addr = ("127.0.0.1", 10087)  # Proxy server IP and port
    tcp_server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    tcp_server_socket.bind(ip_addr)
    tcp_server_socket.listen(5)

    block_ip = {"8.8.8.8"}
    print("Proxy Server is running...")

    try:
        while True:
            client_socket, client_addr = tcp_server_socket.accept()
            print(f"Connection from {client_addr}")

            try:
                recv_data = client_socket.recv(1024).decode('utf-8')
                json_data = json.loads(recv_data)

                # Check if the server IP is in the blocklist
                if json_data['server_ip'] in block_ip:
                    client_socket.sendall(b"Error: IP is blocked.")
                else:
                    server_ip = json_data['server_ip']
                    server_port = json_data['server_port']
                    message = json_data['message']

                    # Forward the message to the actual server
                    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as tcp_client_socket:
                        tcp_client_socket.connect((server_ip, server_port))
                        tcp_client_socket.sendall(message.encode('utf-8'))
                        server_response = tcp_client_socket.recv(1024)
                        client_socket.sendall(server_response)

            except json.JSONDecodeError:
                client_socket.sendall(b"Error: Invalid JSON format.")
            except Exception as e:
                print(f"Proxy error: {e}")
                client_socket.sendall(b"Error: Proxy server encountered an issue.")
            finally:
                client_socket.close()
                print("Client connection closed.")

    except KeyboardInterrupt:
        print("Proxy server shutting down.")
    finally:
        tcp_server_socket.close()
        print("Proxy server socket closed.")


if __name__ == "__main__":
    main()
