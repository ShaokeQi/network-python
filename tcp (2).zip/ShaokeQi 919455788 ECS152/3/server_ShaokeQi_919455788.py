import socket


def main():
    ip_addr = ("127.0.0.1", 10086) #udp ip address
    tcp_server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    tcp_server_socket.bind(ip_addr)
    tcp_server_socket.listen(5)
    block_ip = set()
    print('--Server is running--')
     #only need to connect to proxy
    while True:
        client_socket, client_addr = tcp_server_socket.accept()
        recv_data = client_socket.recv(1024)
        print('recv message:', recv_data.decode('utf-8'))
        client_socket.send(recv_data)
        client_socket.close()
    tcp_socket.close()
    return

if __name__ == '__main__':
    main()
    
    
    
