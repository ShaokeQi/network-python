import socket
import json


def main():
    # Prepare the JSON message
    send_data = json.dumps({
        "server_ip": "127.0.0.1",
        "server_port": 10086,
        "message": "ping"
    })

    ip_addr = ("127.0.0.1", 10087)  # Proxy server IP and port
    tcp_client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        print("Connecting to proxy server...")
        tcp_client_socket.connect(ip_addr)
        tcp_client_socket.sendall(send_data.encode('utf-8'))

        # Receive the response from the proxy server
        recv_data = tcp_client_socket.recv(1024)
        print("Received message:", recv_data.decode('utf-8'))

    except ConnectionRefusedError:
        print("Error: Could not connect to proxy server. Please make sure it is running.")
    except Exception as e:
        print(f"Client error: {e}")
    finally:
        tcp_client_socket.close()
        print("Client socket closed.")


if __name__ == "__main__":
    main()
