import socket

def main():
    ip_addr = ("127.0.0.1", 10086)  # Server IP and port
    tcp_server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    tcp_server_socket.bind(ip_addr)
    tcp_server_socket.listen(5)

    print("Server is running...")

    try:
        while True:
            client_socket, client_addr = tcp_server_socket.accept()
            print(f"Connection from {client_addr}")

            try:
                recv_data = client_socket.recv(1024).decode('utf-8')
                print("Received message:", recv_data)

                # Respond with "pong" if the message is "ping"
                if recv_data.strip().lower() == "ping":
                    client_socket.sendall(b"pong")
                else:
                    client_socket.sendall(recv_data.encode('utf-8'))

            except Exception as e:
                print(f"Server error: {e}")
            finally:
                client_socket.close()
                print("Client connection closed.")

    except KeyboardInterrupt:
        print("Server shutting down.")
    finally:
        tcp_server_socket.close()
        print("Server socket closed.")

if __name__ == "__main__":
    main()
