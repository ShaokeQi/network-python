import socket
import json


def main():
    ip_addr = ("127.0.0.1", 10087) #udp ip address
    tcp_server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    tcp_server_socket.bind(ip_addr)
    tcp_server_socket.listen(5)
    block_ip = ["8.8.8.8"]
    print('--Proxy Server is running--')
     #only need to connect to proxy
    while True:
        client_socket, client_addr = tcp_server_socket.accept()
        recv_data = client_socket.recv(1024)
        print('recv message:', recv_data.decode('utf-8'))
        data = recv_data.decode('utf-8')
        json_data = json.loads(data)
        
        if json_data['server_ip'] in block_ip:
            client_socket.send('Error'.encode('utf-8'))
        else:
            tcp_client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            tcp_client_socket.connect((json_data['server_ip'], json_data['server_port']))
            tcp_client_socket.send(json_data['message'].encode('utf-8'))
            recv_data = tcp_client_socket.recv(1024)
            client_socket.send(recv_data)
        client_socket.close()
    tcp_socket.close()
    return

if __name__ == '__main__':
    main()
    
    
    
