import socket
import json


def main():
    send_data = json.dumps({"server_ip":"127.0.0.1","server_port":10086, "message":"ping"})
    ip_addr = ("127.0.0.1", 10087) #udp ip address
    tcp_client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_client_socket.connect(ip_addr)
    tcp_client_socket.send(send_data.encode('utf-8'))
    recv_data = tcp_client_socket.recv(1024)
    print('receive message:', recv_data.decode('utf-8'))
    
    tcp_client_socket.close()
    
    return

if __name__ == '__main__':
    main()
    
    
    
