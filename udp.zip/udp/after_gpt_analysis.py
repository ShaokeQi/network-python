import os
import json
from collections import Counter
from urllib.parse import urlparse

# Directory containing HAR files
har_files_path = "./har_files"

def get_sld(domain):
    """Extract the second-level domain (SLD) from a domain."""
    domain_list = domain.split('.')
    if len(domain_list) < 2:
        return domain
    return '.'.join(domain_list[-2:])

def get_domain_from_url(url):
    """Extract the domain from a URL."""
    return url.lstrip('http').lstrip('s').lstrip('://').split('/')[0]

def main():
    third_party_domain = Counter()
    third_party_cookies = Counter()

    # Process each HAR file
    for filename in os.listdir(har_files_path):
        if not filename.endswith(".har"):
            continue

        filepath = os.path.join(har_files_path, filename)
        domain = filename[:-4]  # Assuming HAR filename is the domain (e.g., "example.com.har")
        sld = get_sld(domain)

        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                har_data = json.load(f)
                entries = har_data.get('log', {}).get('entries', [])
        except Exception as e:
            print(f"Error reading {filename}: {e}")
            continue

        # Analyze network requests
        for entry in entries:
            try:
                request_url = entry['request']['url']
                request_domain = get_domain_from_url(request_url)
                request_sld = get_sld(request_domain)

                # Check for third-party domains
                if request_sld != sld:
                    third_party_domain[request_sld] += 1

                # Analyze third-party cookies
                response_headers = entry['response'].get('headers', [])
                for header in response_headers:
                    if header['name'].lower() == 'set-cookie':
                        cookie_name = header['value'].split('=')[0]
                        third_party_cookies[f"{request_sld}/{cookie_name}"] += 1
            except KeyError:
                continue  # Skip invalid entries

    # Sort and get top 10
    top_third_party_domains = third_party_domain.most_common(10)
    top_third_party_cookies = third_party_cookies.most_common(10)

    # Output results
    print("Top 10 Third-Party Domains:")
    for domain, count in top_third_party_domains:
        print(f"{domain}: {count} requests")

    print("\nTop 10 Third-Party Cookies:")
    for cookie, count in top_third_party_cookies:
        domain, cookie_name = cookie.split('/')
        print(f"{cookie_name} (from {domain}): {count} times")

    # Save results to JSON
    results = {
        "third_party_domains": top_third_party_domains,
        "third_party_cookies": top_third_party_cookies
    }
    with open("analysis_results.json", "w") as outfile:
        json.dump(results, outfile, indent=4)

if __name__ == "__main__":
    main()
