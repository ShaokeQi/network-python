import os
import json


def get_domain_from_url(url):
    return url.lstrip('http').lstrip('s').lstrip('://').split('/')[0]


def get_sld(domain):
    domain_list = domain.split('.')
    if len(domain_list) < 2:
        return domain
    return '.'.join(domain_list[-2:])


def main():
    har_files_path = "./har_files"
    third_party_domain = {}
    third_party_cookies = {}
    for filename in os.listdir(har_files_path):
        filepath = os.path.join(har_files_path, filename)
        domain = filename[:len(filename) - 4]  # ignore .har
        sld = get_sld(domain)
        with open(filepath, 'r', encoding='utf-8') as f:
            har_data = json.load(f)
            entries = har_data.get('log', {}).get('entries', [])

            for entry in entries:
                url_t = entry['request']['url']
                domain_t = get_domain_from_url(url_t)
                if get_sld(domain_t) != sld:
                    third_party_domain[get_sld(domain_t)] = third_party_domain.get(get_sld(domain_t), 0) + 1
                    #this is a dictionar that keeps track of the number of occurrences of each third-party domain name.
                    # If the current domain name does not exist, it returns the default value of 0 and counts +1
                    cookies_from_response = entry['response'].get('cookies', [])
                    for cookie in cookies_from_response:
                        cookie_name = cookie['name']
                        cookie_value = cookie['value']
                        third_party_domain_cookie = f"{domain_t}/{cookie_name}"
                        third_party_cookies[third_party_domain_cookie] = third_party_cookies.get(
                            third_party_domain_cookie, 0) + 1

    third_party_domain_list = sorted(third_party_domain.items(), key=lambda x: x[1], reverse=True)
    cookies_list = sorted(third_party_cookies.items(), key=lambda x: x[1], reverse=True)
    print('Top 10 third party domains')
    for i in range(min(10, len(third_party_domain_list))):
        print(f'{third_party_domain_list[i][1]}: {third_party_domain_list[i][0]} requests')

    print('Top 10 third party cookies')
    for i in range(min(10, len(cookies_list))):
        print(f'{cookies_list[i][1]}: {cookies_list[i][0]} times')
    return


if __name__ == '__main__':
    main()