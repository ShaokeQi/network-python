from selenium import webdriver
from browsermobproxy import Server
import json
import time

# Start BrowserMob Proxy
server = Server("./browsermob-proxy/bin/browsermob-proxy", options={'port': 9090})
server.start()
proxy = server.create_proxy()

# those part are Selenium WebDriver configuration with proxy
options = webdriver.ChromeOptions()
options.add_argument(f"--proxy-server={proxy.proxy}")
options.add_argument('--ignore-certificate-errors')
options.add_argument("--headless")

driver = webdriver.Chrome(options=options)

# Load the list of websites
websites = []
with open("top-1m.csv", "r") as f:
    websites = []
    for line in f:
        websites.append(line.strip().split(',')[1])
        if len(websites) >= 1000:
            break

# Crawl websites and save HAR files
for site in websites:
    try:
        # Start capturing HTTP traffic
        print(site)
        proxy.new_har(site, options={'captureHeaders': True, 'captureContent': True, 'captureCookies': True})

        # Visit the website
        driver.get(f"http://{site}")
        proxy.wait_for_traffic_to_stop(500, 100)

        # Save the HAR file
        har_data = proxy.har
        with open(f"./har_files/{site}.har", "w") as har_file:
            json.dump(har_data, har_file)
        print(f"Saved HAR file for {site}")
    except Exception as e:
        print(f"Failed to process {site}: {e}")

# Cleanup
driver.quit()
proxy.close()
server.stop()